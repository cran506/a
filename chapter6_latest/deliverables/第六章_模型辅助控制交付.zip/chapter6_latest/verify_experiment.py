"""核对交付 CSV，用更严格积分复算，并记录未知外载对照与测试结果。"""
import argparse
from dataclasses import fields
import hashlib
import io
import json
import math
import os
from pathlib import Path
import tempfile
import unittest

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir())/"chapter6-mpl"))
os.environ.setdefault("XDG_CACHE_HOME", str(Path(tempfile.gettempdir())/"chapter6-cache"))
import numpy as np
from simulation import Experiment, simulate

ROOT = Path(__file__).resolve().parent
CORE = ("simulation.py", "model_assisted_controller.py", "twin_adapter.py", "controllers.py",
        "trajectory.py", "hydraulic_digital_twin.py", "physical_config.json", "classroom_config.json")
ORIGINAL_TWIN_SHA256 = "6cac5f1122be9e5f26728f0354aaa26e15836669a2496b0dc442e51301e7332f"


def source_hashes():
    return {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in CORE}


def read_data(path):
    array = np.genfromtxt(path, delimiter=",", names=True)
    return {name: array[name] for name in array.dtype.names}


def check_data(data):
    t = data["time_s"]
    checks = dict(finite=all(np.all(np.isfinite(v)) for v in data.values()),
                  sample_count_correct=len(t)==1201,
                  clock_correct=np.allclose(t,np.arange(1201)*.001,rtol=0,atol=1e-12),
                  positive_pressure=min(data["p1_pa"].min(),data["p2_pa"].min())>0,
                  voltage_bounded=np.max(abs(data["voltage_v"]))<=10+1e-12,
                  valve_bounded=np.max(abs(data["valve_normalized"]))<=1+1e-12,
                  output_composition=np.allclose(data["voltage_v"],
                                                data["feedforward_v"]+data["feedback_v"],atol=1e-12))
    return {key: bool(value) for key,value in checks.items()}


def verify(output, independent_prefix=None):
    output = Path(output)
    summary = json.loads((output/"summary.json").read_text())
    if summary["scenario"] != "known_planned_process_load":
        raise ValueError("此验收入口检查默认已知工艺基准；未知负载作为独立对照记录")
    hashes = source_hashes()
    if hashes["hydraulic_digital_twin.py"] != ORIGINAL_TWIN_SHA256:
        raise AssertionError("上传的原始 twin 已发生修改")
    report = {"source_sha256": hashes, "original_twin_unchanged": True,
              "scenario": summary["scenario"], "csv_checks": {},
              "tighter_integration": {}, "unknown_load": {}, "acceptance": {}}
    data = {key: read_data(output/f"{key}.csv") for key in ("pid","nominal","full")}
    for key in data:
        checks = check_data(data[key])
        if not all(checks.values()):
            raise AssertionError(f"{key} 数据检查失败：{checks}")
        for name in ("time_s","reference_m","reference_velocity_m_s","load_n"):
            np.testing.assert_array_equal(data["pid"][name],data[key][name])
        report["csv_checks"][key] = checks
    experiment_fields = {item.name for item in fields(Experiment)}
    tight_results = {}
    for key in ("pid","nominal","full","unknown"):
        original = summary["strategies"]["full" if key=="unknown" else key]["config"]
        values = {name:value for name,value in original.items() if name in experiment_fields}
        values.update(name=f"independent_{key}",rtol=original["rtol"]/10,known_load=key!="unknown")
        if independent_prefix:
            prefix = str(independent_prefix)
            meta = json.loads(Path(f"{prefix}{key}.json").read_text())
            if meta["source_sha256"] != hashes:
                raise AssertionError("独立复算所用核心源码与当前文件不一致")
            for name,value in values.items():
                actual = meta["config"][name]
                matches = math.isclose(actual,value,rel_tol=1e-14,abs_tol=0.) if isinstance(value,float) else actual==value
                if not matches:
                    raise AssertionError(f"{key} 独立复算条件不一致：{name}")
            with np.load(f"{prefix}{key}.npz") as saved:
                result = dict(data={name:saved[name].copy() for name in saved.files},
                              config=meta["config"],metrics=meta["metrics"])
        else:
            result = simulate(Experiment(**values))
        checks = check_data(result["data"])
        if not all(checks.values()):
            raise AssertionError(f"{key} 更严格积分失败：{checks}")
        tight_results[key] = result
        entry = dict(config=result["config"],metrics=result["metrics"],checks=checks)
        if key!="unknown":
            delta = float(np.max(abs(data[key]["position_m"]-result["data"]["position_m"]))*1000)
            entry["max_position_difference_mm"] = delta
            entry["difference_under_quarter_adc_lsb"] = delta<original["sensor_lsb_mm"]/4
            if not entry["difference_under_quarter_adc_lsb"]:
                raise AssertionError(f"{key} 积分收敛差超过四分之一 ADC 步长")
            report["tighter_integration"][key] = entry
        else:
            report["unknown_load"] = entry
    unknown = tight_results["unknown"]["data"]
    if np.any(unknown["planned_force_n"] != 0):
        raise AssertionError("未知外载对照含计划力输入")
    before_load = unknown["time_s"]<=.5
    for name in ("position_m","velocity_m_s","p1_pa","p2_pa","voltage_v"):
        np.testing.assert_array_equal(unknown[name][before_load],tight_results["full"]["data"][name][before_load])
    metrics = tight_results["full"]["metrics"]
    acceptance = dict(known_full_max_error_under_0p05mm=metrics["max_abs_error_mm"]<.05,
                      full_start_matches_reference=metrics["motion_start_ms"]==metrics["reference_threshold_ms"],
                      full_load_speed_drop_under_3percent=metrics["contact_speed_drop_percent"]<3,
                      full_no_saturation=metrics["saturation_time_s"]==0,
                      unknown_has_no_planned_force=True,commands_identical_before_load=True)
    report["acceptance"] = acceptance
    if not all(acceptance.values()):
        raise AssertionError(f"默认课堂基准验收失败：{acceptance}")
    stream = io.StringIO()
    tests = unittest.defaultTestLoader.discover(str(ROOT),pattern="test_chapter6.py")
    tested = unittest.TextTestRunner(stream=stream).run(tests)
    if not tested.wasSuccessful():
        raise AssertionError(stream.getvalue())
    report["unit_tests"] = dict(run=tested.testsRun,passed=tested.wasSuccessful())
    report["scope"] = "Accuracy threshold applies to known model-matched process load only. Unknown load has force/rate=0; its actual error is reported without the accuracy claim."
    (output/"validation.json").write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
    print(f"验证通过：{tested.testsRun}项测试，三组收敛复核及未知外载因果对照；记录于 {output/'validation.json'}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=ROOT/"outputs")
    parser.add_argument("--independent-prefix",type=Path,help="复用带源码 SHA 的独立复算 NPZ/JSON 前缀")
    args = parser.parse_args()
    verify(args.output,args.independent_prefix)
