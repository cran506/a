# 第八章课堂实验：按五维参考接口重新训练

本版依据第八章 PPT 和提供的训练代码实现。保留五维观察、动作电压范围、指定标准化参数和奖励公式；数字孪生由四状态液压方程推进。

**按本次选择，主图 (a) 采用 PPT 三阶段教学示意，明确标注“非训练日志”。** 奖励 −180→−2、熵 2.8→0.35 由公开目标锚点插值表达，不作为实测证据。图 (b)–(d) 保留原部署对照的实际数据；[此前实测四联图](outputs/chapter8_measured_comparison.png) 另存。

本次还取消教师预热，重新完成一次真实从零百万步 SAC 训练。其 [完整训练曲线](../chapter8_from_scratch/outputs/sac_training_actual.png)、[固定工况验证](../chapter8_from_scratch/outputs/training_validation.png)、[全部代码与原始日志](../chapter8_from_scratch/README.md) 单独提供；主图示意与这次真实数据不混称。

- [运行入口](drl_hydraulic_lab.py)
- [四联图](outputs/chapter8_comparison.png) / [PDF](outputs/chapter8_comparison.pdf)
- [真实训练日志](outputs/training.csv) / [训练元数据](models/training_metadata.json)
- [四策略闭环记录](outputs/evaluation.csv) / [量化、计时与性能指标](outputs/metrics.json)
- [HOCBF 验证](outputs/safety_summary.json)
- [上传的原始参考文件](materials/user_training_reference.py) / [第八章课件](materials/chap08-ppt.pdf)
- [真实从零训练附件（含完整复现实验 ZIP）](actual_training/README.md)

## 本次运行结果

以下数据来自同一四状态对象的独立闭环，未裁剪速度曲线。

| 策略 | 故障后速度谷值 (mm/s) | 持续恢复至 ±1 mm/s | 末 0.1 s 速度偏差 (mm/s) |
| --- | ---: | ---: | ---: |
| 固定 PID | −50.16 | 本窗口未恢复 | +1.047 |
| 空载标称前馈 | −50.30 | 本窗口未恢复 | −25.297 |
| 精修后的 SAC FP32 | −16.38 | 21 ms | +0.008 |
| 70% 剪枝，INT8 权重 / INT16 激活 | −16.44 | 23 ms | +0.008 |

FP32/整数版在全显示窗口的速度 RMS 差约 **0.146 mm/s**；故障前电压标准差分别约 0.00017/0.026 V。安全实验最低电压 −3.092 V，1 s 位置 98.800 mm，未保护首次触边 0.104891 s。33 项单元检查和完整物理/策略重放校验的最新结果见 `outputs/validation.json`。

实际 SAC 最后一条原始奖励约 −2.354、电压微分熵约 −0.310 nat，未强制拟合课件的 −2/0.35 平台。精修后稳态电压约 6.679 V、峰值约 9.97 V；谷值时刻 0.502 s。这些数值仍与课件 6.50 V、9.10 V、0.522 s 不同。标称前馈基准保持空载逆解 3.510 V，其静差约 −25.3 mm/s；在本共同孔口模型中，不能同时把它改成 5.35 V 并维持同样静差。

最终整数工件 9003 B，FP32 actor 工件 18421 B，实际缩减约 51.1%。本机单观察整数内核计时中位数约 0.038 ms；这是 NumPy CPU 实测，包含量化输入仿射和输出 tanh，不含传感 Z-score、ODE、通信和安全滤波，也不代表 MCU 基准。

## 安装与运行

需要 Python 3.11 或更新版本、`g++`；中文字体建议安装 Noto Sans CJK SC。C++ 内核只加速同一组微分方程的积分，SAC 使用 Stable-Baselines3/PyTorch。

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python drl_hydraulic_lab.py --mode all --reuse-model
```

保留所附策略重新评估可使用上述 `--reuse-model`。重新执行教师初始化、SAC 训练及单独绘图：

```bash
python drl_hydraulic_lab.py --mode all --timesteps 1000000 --seed 2026
python drl_hydraulic_lab.py --mode evaluate
python reporting.py
python safety_experiment.py
```

重新训练会更换检查点和日志，性能与耗时依随机种子和硬件而变。本目录的模型只接受五维观察，与此前十维模型不兼容。

## 观察、奖励与域随机化

网络输入严格为 `[e, de, dde, PL, Ps]`，单位分别为 mm、mm/s、mm/s²、MPa、MPa。误差方向统一为“实际减参考”；`PL=P1−(A2/A1)P2` 为非对称缸的等效负载压力。均值 `[0,0,0,10,21]`、标准差 `[10,50,500,8,2]` 按参考使用。这些是固定工程统计量，不称为本次训练样本拟合后的经验统计量。

动作 `a∈[-1,1]` 映射到 `u=10a V`。每步原始奖励为：

```text
r = -100 e_mm² - 0.1 u_V² - (u_V-u_prev_V)²
    + 2（当 |e_mm| < 0.2）
```

物理失败终止单独扣分并写入信息字段。训练优化器可使用公开的奖励数值缩放，图和 CSV 保存缩放前的原始奖励。`reward_mean` 是已完成回合的平均每步回报的滚动均值；实际步数、更新次数与训练参数见元数据。动作熵由 actor 的 tanh 修正对数概率计算，电压单位下 `H(u)=H(a)+ln(10)`；微分熵允许为负。

每回合通过带种子的 Gym 随机数源随机化质量 ±20%、标称体积模量 600–1400 MPa、库伦摩擦 ±30%。这些参数均进入动力学。另公开加入随机负载和刚度故障增强，其范围见训练元数据；测试是训练包络覆盖下的仿真鲁棒性验证。仅五维压缩观察不能完全恢复隐藏容积、未知参数和历史输入，因此不能据此宣称严格全状态可观测。

## 训练初始化与稳定更新

新五输入 actor 先拟合一个只读取相同五维观测的近似机理教师；预热数据和监督梯度步数单独记录，不计入百万步 SAC 交互。之后进行真实 SAC 训练，actor 目标增加公开的教师一致性项 `100 × MSE(tanh(μθ(s)), a_teacher(s))`，防止随机初始 critic 破坏稳定策略。教师只在训练阶段使用，部署的 FP32/INT8 均独立运行网络，不叠加教师电压。详见 [初始化代码](teacher_initialization.py) 和训练元数据。

因此本版是“机理先验正则化 SAC”，不是无引导的纯 SAC 从零学习。图 (a) 显示真实训练回报，起点已包含监督预热效果；色带只对应课件给定步数区间，不宣称实际必然出现三段 S 形曲线。失败终止额外扣分 −100000，原始奖励公式另存 `base_reward`；这项训练终止成本不作为安全保证。失败尝试的完整中间工件留在本地 `trials/`，GitHub 和 ZIP 仅保留 `outputs/diagnostics/` 中的小型审计日志。

SAC 完成后另有一次明确记录的离线机理教师精修，约束输出均值及其对五维输入的局部雅可比，处理低容积、1 ms 采样时容易被平均回报掩盖的巡航电压振荡。该阶段的梯度步数不计入 SAC 百万步，部署模型与精修前模型分别保存。图 (a) 保留 SAC 阶段的原始日志，图 (c)(d) 评估精修后模型；精修使用过的名义工况属于校准，不能当作完全留出验证。详见 [精修代码](teacher_consolidation.py) 和 `models/teacher_consolidation.json`。

## 共同物理对象与四策略

`hydraulic_twin.py` 和 `native_twin.cpp` 积分 `[x,v,P1,P2]`：惯性受力、两腔连续性、变容积、压缩性、有向孔口、内泄漏、补油和泄压。完整教学参数在 [physical_config.json](physical_config.json)，其中 `m=250 kg`、`Ps=21 MPa`、`A1=3.8×10⁻⁴ m²`、`A2=2.1×10⁻⁴ m²`、无杆腔死容积 `0.1 mL`、阀死区 `±0.5 V`。该参数集不是从截图反求得到的辨识结果。

四策略均从全局 `0.4 s` 的同一个 50 mm/s 巡航平衡点出发；在 `0.5 s` 同时增加 5000 N 负载并将体积模量乘以 0.5，采样 1 ms，结束于 `1.0 s`。控制器只能读取自身闭环观察。

| 策略 | 实际控制规则 |
| --- | --- |
| PID | 固定位置 PID，含巡航电压偏置、不完全微分及条件积分抗饱和；不读取故障标签 |
| 标称前馈 | 空载平衡受力与孔口逆解所得电压；没有未知负载先验、实时增益调度或积分修正 |
| SAC FP32 | 新训练的五输入策略，使用确定性均值动作 |
| 剪枝 INT8 | 独立加载整数 actor、独立演化自身状态，不重放 FP32 轨迹 |

末 0.1 s 均值、故障后 RMS、峰值及电压均从原始 CSV 计算。恢复判据为峰值后始终满足 `|速度误差|≤1 mm/s`，且保留至少 50 ms 记录。确定性评估没有叠加人工正弦颤振；当前连续摩擦近似不包含集合值静摩擦粘住分支，不能把非零熵直接当作消除爬行的证明。

## 上传参考与截图为何不能逐点同时满足

原始文件保存在 `materials/user_training_reference.py`。它将误差递推称为四阶物理模型，但质量和摩擦随机量未进入该递推，压力更新缺少 `dt` 且压力不反馈机械受力。其“极速训练”设置也与此次粘贴的百万步、2000 步回合及奖励权重不同。

在该参考递推的 `β/β₀=0.5`、5000 N、`|u|≤10 V` 条件下，速度误差满足：

```text
de[k+1] = 0.982 de[k] + 0.001(6.25u[k] - 40)
```

若初始误差为零，最不利稳态下界为 `−102.5/18=−5.6944 mm/s`；因而仅修改 SAC 训练，无法在该递推中得到截图的 `−14.1 mm/s` 或 `−48 mm/s` 谷值。本版保留参考接口和奖励，修正这些物理关系后重新训练。图中的压力、速度、电压必须满足同一个对象，不能分别调整到截图数值；具体残差由实际结果与指标文件直接呈现。

## HOCBF-QP 与边缘压缩

安全子图采用独立二阶教学模型 `ẋ=v, v̇=ku−cv`（mm、mm/s），配置见 `safety_config.json`。对 0–100 mm 机械区间保留 1.2 mm 内缩裕度；标量 QP 进行最小距离区间投影，同时检查初始高阶条件及整个采样保持区间。不可行时明确抛错，不以一个违反约束的电压冒充安全解。未保护轨迹首次触边即终止。

上传示例的 `α1=48, α2=580` 不能分解为两个正实递归增益；另提供接近该参数的 `safety_reference_config.json`（24、24，对应 48、576）供比较。默认演示参数及数值验证均在输出 JSON 中公开。二阶模型的证书不直接等同于四状态液压对象或真机的安全证明。

```bash
python safety_experiment.py --config safety_reference_config.json --output-dir outputs/safety_reference
```

边缘模块按幅值剪除约 70% 连接，固定掩码后按校准观察进行蒸馏和精修，并匹配最终 FP32 网络在巡航点附近的输入雅可比，避免仅匹配平均输出却引入高频振荡。本次实测全 W8/A8 激活网格会在巡航点诱发限环，因此最终采用 **INT8 权重、INT16 激活、INT32 累加和 INT64 定点重缩放**；最后 tanh 边界反量化。权重保持 INT8，运行不使用浮点矩阵乘法；明确不把混合精度实现称为全 W8/A8。原 W8/A8、浮点激活及剪枝浮点对照数据保留在 `outputs/diagnostics/`。

工件独立加载后与内存中整数路径逐位核对。校准中显式加入一次 FP32 commissioning 轨迹和标记清楚的局部回归样本，该轨迹不称为完全留出测试；另外的 replay 留出观察不用于选参。

压缩率按实际工件字节统计；计时包含 CPU 单观察 actor 内核及输入/输出变换，排除 ODE、传感通信、SAC API 和安全滤波。稀疏权重存储与实际整数运行时间并不自动等于课件中的 92.5% 或 MCU 的 0.06 ms，实际值见 `outputs/metrics.json`。
